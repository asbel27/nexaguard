<?php
if (!defined('ABSPATH')) {
    exit;
}
$license = get_option('nexaguard_license_data', null);
$has_license = !empty($license) && !empty($license['valid']) && !empty($license['key']);
?>

<!-- Modal de Conversión: Plan PRO vs Especialista en Ciberseguridad (Plan Rescate) -->
<div id="clean-upgrade-modal" class="ng-modal" style="display:none;">
    <div class="ng-modal-box clean-upgrade-box">
        <div class="cum-head">
            <span class="cum-tag">🛡️ ELEVA LA SEGURIDAD DE TU SITIO WEB</span>
            <h3 id="cum-modal-title">Desbloquea la Protección Total y Vigilancia de tu Web</h3>
            <p id="cum-modal-desc">El <strong>Sistema de Vigilancia 24H con Radar</strong>, el <strong>Blindaje WAF en Vivo</strong> y la <strong>Erradicación con 1 Clic</strong> están reservados para licencias PRO o la intervención de nuestros expertos en ciberseguridad. Elige tu opción:</p>
        </div>

        <div class="cum-grid">
            <!-- Opción 1: Plan Security Pro -->
            <div class="cum-card cum-card-pro">
                <div class="cum-card-badge">MÁS POPULAR · $9.99 / MES</div>
                <h4>Plan NexaGuard Security PRO</h4>
                <div class="cum-price"><b>$9.99</b> <span>USD / mes</span></div>
                <ul class="cum-features">
                    <li>✓ <strong>Sistema de Vigilancia 24 Horas</strong> con radar táctico continuo activo</li>
                    <li>✓ <strong>Blindaje y Cortafuegos WAF</strong> con filtro Anti-ClearFake en vivo</li>
                    <li>✓ <strong>Erradicación con 1 Clic</strong> de todas las amenazas detectadas</li>
                    <li>✓ <strong>Zero-Day Cloud Threat Intel:</strong> Bloquea ataques nuevos</li>
                    <li>✓ <strong>Prevención de Reinfecciones</strong> y blindaje perimetral</li>
                </ul>
                <a href="https://www.nexaguards.com/#planes" target="_blank" class="btn-ng btn-ng-primary" style="width:100%;text-align:center;justify-content:center">Adquirir Plan PRO ($9.99/mes)</a>
                <button type="button" class="btn-ng btn-ng-link btn-switch-to-key" style="margin-top:8px;color:#ffcf33;font-size:0.82rem;width:100%;text-align:center">Ya tengo mi clave de licencia ›</button>
            </div>

            <!-- Opción 2: Especialista en Ciberseguridad / Plan Rescate -->
            <div class="cum-card cum-card-rescate">
                <div class="cum-card-badge-o">ESPECIALISTA EN CIBERSEGURIDAD · $99</div>
                <h4>Ayuda de un Especialista Forense</h4>
                <div class="cum-price"><b>$99</b> <span>USD · Pago Único</span></div>
                <ul class="cum-features">
                    <li>✓ <strong>Limpieza Humana Completa</strong> por ingenieros en ciberseguridad</li>
                    <li>✓ <strong>Reparación de Errores Críticos:</strong> Web operativa al 100%</li>
                    <li>✓ <strong>Deslistado Urgente de Listas Negras:</strong> Google y antivirus</li>
                    <li>✓ <strong>Auditoría Forense Profunda:</strong> Cerramos la brecha de entrada</li>
                    <li>✓ <strong>Garantía Total de 30 Días:</strong> Si vuelve, lo limpiamos gratis</li>
                </ul>
                <a href="https://www.nexaguards.com/#contacto" target="_blank" class="btn-ng btn-ng-danger" style="width:100%;text-align:center;justify-content:center">👨‍💻 Solicitar Especialista (Plan Rescate $99)</a>
                <p style="font-size:0.78rem;color:#8f9fc7;margin-top:8px;text-align:center">Intervención prioritaria urgente en menos de 1 a 2 horas</p>
            </div>
        </div>

        <div class="cum-foot">
            <button type="button" id="btn-close-clean-modal" class="btn-ng btn-ng-outline">Cerrar</button>
        </div>
    </div>
</div>

<!-- Modal de Cambio / Ingreso de Licencia -->
<div id="license-modal" class="ng-modal" style="display:none;">
    <div class="ng-modal-box">
        <h3>🔑 Activar Licencia NexaGuard Pro</h3>
        <p>Introduce tu clave de licencia oficial obtenida tras la compra de tu plan en NexaGuard:</p>
        <div class="ng-modal-fld">
            <input type="text" id="input-license-key" class="in-ng" placeholder="Ej: NXG-PRO-XXXX-XXXX" value="<?php echo esc_attr($has_license ? $license['key'] : ''); ?>">
        </div>
        <p id="license-modal-msg" class="modal-msg"></p>
        <div class="ng-modal-acts">
            <button type="button" id="btn-save-license" class="btn-ng btn-ng-primary">Verificar y Guardar</button>
            <button type="button" id="btn-close-license" class="btn-ng btn-ng-outline">Cancelar</button>
        </div>
    </div>
</div>

<!-- Modal Interactivo y Estilizado de Confirmación NexaGuard (Reemplaza confirm() nativo) -->
<div id="nexaguard-confirm-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box" style="max-width:520px; border:1.5px solid rgba(255,207,51,0.5); box-shadow:0 25px 60px rgba(0,0,0,0.85), 0 0 30px rgba(255,207,51,0.15);">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px;">
            <span id="ng-confirm-icon" style="font-size:2rem; line-height:1;">🛡️</span>
            <div>
                <h3 id="ng-confirm-title" style="margin:0; font-size:1.2rem; color:#ffffff;">Confirmación de Seguridad</h3>
                <small style="color:#ffcf33; font-weight:700; font-size:0.75rem; letter-spacing:0.04em;">NEXAGUARD INTELLIGENT FORENSICS</small>
            </div>
        </div>
        <p id="ng-confirm-message" style="color:#dbe4ff; font-size:0.92rem; line-height:1.6; margin:0 0 20px; white-space:pre-line;"></p>
        <div class="ng-modal-acts" style="display:flex; gap:10px; justify-content:flex-end; border-top:1px solid rgba(255,255,255,0.08); padding-top:16px;">
            <button type="button" id="ng-confirm-cancel-btn" class="btn-ng btn-ng-outline" style="min-width:105px;">Cancelar</button>
            <button type="button" id="ng-confirm-ok-btn" class="btn-ng btn-ng-primary" style="min-width:140px;">Continuar</button>
        </div>
    </div>
</div>

<!-- Modal Interactivo: Acción Bloqueada · Invitación a Plan PRO -->
<div id="nexaguard-action-blocked-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box action-blocked-box" style="max-width:540px; border:2px solid #ff4560; background:linear-gradient(180deg, #160c22 0%, #0c112e 100%); box-shadow:0 30px 70px rgba(0,0,0,0.9), 0 0 35px rgba(255,69,96,0.25); text-align:center; padding:32px 28px;">
        <div style="width:68px; height:68px; margin:0 auto 16px; border-radius:50%; background:rgba(255,69,96,0.15); border:2px solid #ff4560; display:flex; align-items:center; justify-content:center; font-size:2rem; box-shadow:0 0 20px rgba(255,69,96,0.35);">
            🔒
        </div>
        <span style="display:inline-block; font-size:0.75rem; font-weight:900; letter-spacing:0.08em; color:#ff8ba0; background:rgba(255,69,96,0.18); border:1px solid rgba(255,69,96,0.4); padding:4px 12px; border-radius:999px; margin-bottom:12px;">
            FUNCIÓN RESTRINGIDA EN EDICIÓN ESTÁNDAR
        </span>
        <h3 style="font-size:1.35rem; font-weight:800; color:#ffffff; margin:0 0 10px; text-transform:uppercase; letter-spacing:0.02em;">
            LO SENTIMOS, LA ACCIÓN NO SE EJECUTÓ
        </h3>
        <p style="color:#cad7f5; font-size:0.94rem; line-height:1.6; margin:0 0 22px; font-weight:500;">
            La <strong>erradicación automática de malware</strong>, la <strong>desinfección de archivos infectados</strong> y el <strong>aislamiento en cuarentena</strong> requieren el motor activo de <strong style="color:#ffcf33;">NexaGuard Security PRO</strong>.
        </p>
        
        <div style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,207,51,0.25); border-radius:12px; padding:16px 18px; margin-bottom:24px; text-align:left;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
                <span style="color:#ffcf33; font-weight:800; font-size:0.88rem;">⚡ PLAN NEXAGUARD SECURITY PRO</span>
                <span style="color:#3de8a4; font-weight:800; font-size:0.95rem;">$9.99 <span style="font-size:0.75rem; color:#a0acd2;">/ mes</span></span>
            </div>
            <ul style="margin:0; padding-left:18px; color:#dbe4ff; font-size:0.82rem; line-height:1.6;">
                <li>✓ Limpieza y eliminación ilimitada de amenazas con 1 clic</li>
                <li>✓ Restauración limpia de archivos Core desde WordPress.org</li>
                <li>✓ Bóveda de Cuarentena y Puntos de Reversión automáticos</li>
            </ul>
        </div>

        <div style="display:flex; flex-direction:column; gap:10px;">
            <a href="https://www.nexaguards.com/#planes" target="_blank" class="btn-ng btn-ng-primary" style="justify-content:center; font-size:1rem; padding:12px 20px;">
                ⚡ Adquirir Plan PRO ($9.99/mes)
            </a>
            <div style="display:flex; gap:10px; justify-content:center; align-items:center; flex-wrap:wrap; margin-top:4px;">
                <button type="button" class="btn-ng btn-ng-link btn-switch-to-key" style="color:#ffcf33; font-size:0.84rem; text-decoration:underline;">
                    🔑 Ya tengo mi clave de licencia
                </button>
                <span style="color:rgba(255,255,255,0.25);">·</span>
                <button type="button" id="btn-close-action-blocked" class="btn-ng btn-ng-outline" style="font-size:0.84rem; padding:6px 16px;">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
</div>

<?php
if (!defined('ABSPATH')) {
    exit;
}
$license = get_option('nexaguard_license_data', null);
$has_license = !empty($license) && !empty($license['valid']) && !empty($license['key']);
?>

<!-- Modal de Conversión: Plan PRO vs Especialista en Ciberseguridad (Plan Rescate) -->
<div id="clean-upgrade-modal" class="ng-modal" style="display:none;">
    <div class="ng-modal-box clean-upgrade-box">
        <div class="cum-head">
            <span class="cum-tag">🛡️ ELEVA LA SEGURIDAD DE TU SITIO WEB</span>
            <h3 id="cum-modal-title">Desbloquea la Protección Total y Vigilancia de tu Web</h3>
            <p id="cum-modal-desc">El <strong>Sistema de Vigilancia 24H con Radar</strong>, el <strong>Blindaje WAF en Vivo</strong> y la <strong>Erradicación con 1 Clic</strong> están reservados para licencias PRO o la intervención de nuestros expertos en ciberseguridad. Elige tu opción:</p>
        </div>

        <div class="cum-grid">
            <!-- Opción 1: Plan Security Pro -->
            <div class="cum-card cum-card-pro">
                <div class="cum-card-badge">MÁS POPULAR · $9.99 / MES</div>
                <h4>Plan NexaGuard Security PRO</h4>
                <div class="cum-price"><b>$9.99</b> <span>USD / mes</span></div>
                <ul class="cum-features">
                    <li>✓ <strong>Sistema de Vigilancia 24 Horas</strong> con radar táctico continuo activo</li>
                    <li>✓ <strong>Blindaje y Cortafuegos WAF</strong> con filtro Anti-ClearFake en vivo</li>
                    <li>✓ <strong>Erradicación con 1 Clic</strong> de todas las amenazas detectadas</li>
                    <li>✓ <strong>Zero-Day Cloud Threat Intel:</strong> Bloquea ataques nuevos</li>
                    <li>✓ <strong>Prevención de Reinfecciones</strong> y blindaje perimetral</li>
                </ul>
                <a href="https://www.nexaguards.com/#planes" target="_blank" class="btn-ng btn-ng-primary" style="width:100%;text-align:center;justify-content:center">Adquirir Plan PRO ($9.99/mes)</a>
                <button type="button" class="btn-ng btn-ng-link btn-switch-to-key" style="margin-top:8px;color:#ffcf33;font-size:0.82rem;width:100%;text-align:center">Ya tengo mi clave de licencia ›</button>
            </div>

            <!-- Opción 2: Especialista en Ciberseguridad / Plan Rescate -->
            <div class="cum-card cum-card-rescate">
                <div class="cum-card-badge-o">ESPECIALISTA EN CIBERSEGURIDAD · $89</div>
                <h4>Ayuda de un Especialista Forense</h4>
                <div class="cum-price"><b>$89</b> <span>USD · Pago Único</span></div>
                <ul class="cum-features">
                    <li>✓ <strong>Limpieza Humana Completa</strong> por ingenieros en ciberseguridad</li>
                    <li>✓ <strong>Reparación de Errores Críticos:</strong> Web operativa al 100%</li>
                    <li>✓ <strong>Deslistado Urgente de Listas Negras:</strong> Google y antivirus</li>
                    <li>✓ <strong>Auditoría Forense Profunda:</strong> Cerramos la brecha de entrada</li>
                    <li>✓ <strong>Garantía Total de 30 Días:</strong> Si vuelve, lo limpiamos gratis</li>
                </ul>
                <a href="https://www.nexaguards.com/#contacto" target="_blank" class="btn-ng btn-ng-danger" style="width:100%;text-align:center;justify-content:center">👨‍💻 Solicitar Especialista (Plan Rescate $89)</a>
                <p style="font-size:0.78rem;color:#8f9fc7;margin-top:8px;text-align:center">Intervención prioritaria urgente en menos de 1 a 2 horas</p>
            </div>
        </div>

        <div class="cum-foot">
            <button type="button" id="btn-close-clean-modal" class="btn-ng btn-ng-outline">Cerrar</button>
        </div>
    </div>
</div>

<!-- Modal de Cambio / Ingreso de Licencia -->
<div id="license-modal" class="ng-modal" style="display:none;">
    <div class="ng-modal-box">
        <h3>🔑 Activar Licencia NexaGuard</h3>
        <p>Introduce tu clave de licencia oficial del Plan PRO obtenida tras tu compra, o activa tu Licencia Comunitaria Gratuita:</p>
        <div class="ng-modal-fld">
            <input type="text" id="input-license-key" class="in-ng" placeholder="Ej: NXG-PRO-XXXX-XXXX" value="<?php echo esc_attr($has_license ? $license['key'] : ''); ?>">
        </div>
        <p id="license-modal-msg" class="modal-msg"></p>
        <div class="ng-modal-acts" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
            <div style="display:flex; gap:8px;">
                <button type="button" id="btn-save-license" class="btn-ng btn-ng-primary">Verificar y Guardar</button>
                <button type="button" id="btn-close-license" class="btn-ng btn-ng-outline">Cancelar</button>
            </div>
            <button type="button" id="btn-get-free-license" class="btn-ng btn-ng-link" style="color:#3de8a4; font-size:0.82rem; font-weight:700;">🛡️ Activar Licencia Gratuita (1-Clic)</button>
        </div>
    </div>
</div>

<!-- Modal Interactivo y Estilizado de Confirmación NexaGuard (Reemplaza confirm() nativo) -->
<div id="nexaguard-confirm-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box" style="max-width:520px; border:1.5px solid rgba(255,207,51,0.5); box-shadow:0 25px 60px rgba(0,0,0,0.85), 0 0 30px rgba(255,207,51,0.15);">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px;">
            <span id="ng-confirm-icon" style="font-size:2rem; line-height:1;">🛡️</span>
            <div>
                <h3 id="ng-confirm-title" style="margin:0; font-size:1.2rem; color:#ffffff;">Confirmación de Seguridad</h3>
                <small style="color:#ffcf33; font-weight:700; font-size:0.75rem; letter-spacing:0.04em;">NEXAGUARD INTELLIGENT FORENSICS</small>
            </div>
        </div>
        <p id="ng-confirm-message" style="color:#dbe4ff; font-size:0.92rem; line-height:1.6; margin:0 0 20px; white-space:pre-line;"></p>
        <div class="ng-modal-acts" style="display:flex; gap:10px; justify-content:flex-end; border-top:1px solid rgba(255,255,255,0.08); padding-top:16px;">
            <button type="button" id="ng-confirm-cancel-btn" class="btn-ng btn-ng-outline" style="min-width:105px;">Cancelar</button>
            <button type="button" id="ng-confirm-ok-btn" class="btn-ng btn-ng-primary" style="min-width:140px;">Continuar</button>
        </div>
    </div>
</div>

<!-- Modal Interactivo: Invitación a NexaGuard Cloud PRO -->
<div id="nexaguard-action-blocked-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box action-blocked-box" style="max-width:540px; border:2px solid #ffcf33; background:linear-gradient(180deg, #160c22 0%, #0c112e 100%); box-shadow:0 30px 70px rgba(0,0,0,0.9), 0 0 35px rgba(255,207,51,0.25); text-align:center; padding:32px 28px;">
        <div style="width:68px; height:68px; margin:0 auto 16px; border-radius:50%; background:rgba(255,207,51,0.15); border:2px solid #ffcf33; display:flex; align-items:center; justify-content:center; font-size:2rem; box-shadow:0 0 20px rgba(255,207,51,0.35);">
            ⚡
        </div>
        <span style="display:inline-block; font-size:0.75rem; font-weight:900; letter-spacing:0.08em; color:#ffcf33; background:rgba(255,207,51,0.18); border:1px solid rgba(255,207,51,0.4); padding:4px 12px; border-radius:999px; margin-bottom:12px;">
            SERVICIOS EN LA NUBE PRO
        </span>
        <h3 style="font-size:1.35rem; font-weight:800; color:#ffffff; margin:0 0 10px; text-transform:uppercase; letter-spacing:0.02em;">
            POTENCIA TU SEGURIDAD CON NEXAGUARD CLOUD
        </h3>
        <p style="color:#cad7f5; font-size:0.94rem; line-height:1.6; margin:0 0 22px; font-weight:500;">
            Conéctate a la red global de ciberinteligencia de <strong style="color:#ffcf33;">NexaGuard Threat Cloud</strong> para recibir firmas Zero-Day en tiempo real, bloqueo colaborativo de botnets (Auto-Jail) y alertas instantáneas por Discord y Telegram.
        </p>
        
        <div style="background:rgba(255,255,255,0.03); border:1px solid rgba(255,207,51,0.25); border-radius:12px; padding:16px 18px; margin-bottom:24px; text-align:left;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
                <span style="color:#ffcf33; font-weight:800; font-size:0.88rem;">⚡ PLAN NEXAGUARD SECURITY PRO</span>
                <span style="color:#3de8a4; font-weight:800; font-size:0.95rem;">$9.99 <span style="font-size:0.75rem; color:#a0acd2;">/ mes</span></span>
            </div>
            <ul style="margin:0; padding-left:18px; color:#dbe4ff; font-size:0.82rem; line-height:1.6;">
                <li>✓ Feeds de telemetría y reglas Zero-Day en vivo desde la nube</li>
                <li>✓ Cárcel colaborativa de IPs maliciosas y botnets (Auto-Jail)</li>
                <li>✓ Notificaciones inmediatas a Discord y Telegram Webhooks</li>
            </ul>
        </div>

        <div style="display:flex; flex-direction:column; gap:10px;">
            <a href="https://www.nexaguards.com/#planes" target="_blank" class="btn-ng btn-ng-primary" style="justify-content:center; font-size:1rem; padding:12px 20px;">
                ⚡ Conocer NexaGuard Cloud PRO ($9.99/mes)
            </a>
            <div style="display:flex; gap:10px; justify-content:center; align-items:center; flex-wrap:wrap; margin-top:4px;">
                <button type="button" class="btn-ng btn-ng-link btn-switch-to-key" style="color:#ffcf33; font-size:0.84rem; text-decoration:underline;">
                    🔑 Ya tengo mi clave de licencia
                </button>
                <span style="color:rgba(255,255,255,0.25);">·</span>
                <button type="button" id="btn-close-action-blocked" class="btn-ng btn-ng-outline" style="font-size:0.84rem; padding:6px 16px;">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Interactivo: Descubre NexaGuard Cloud PRO -->
<div id="nexaguard-quota-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box action-blocked-box" style="max-width:560px; border:2px solid #3de8a4; background:linear-gradient(180deg, #0e1e38 0%, #0c112e 100%); box-shadow:0 30px 70px rgba(0,0,0,0.9), 0 0 35px rgba(61,232,164,0.25); text-align:center; padding:32px 28px;">
        <div style="width:68px; height:68px; margin:0 auto 16px; border-radius:50%; background:rgba(61,232,164,0.15); border:2px solid #3de8a4; display:flex; align-items:center; justify-content:center; font-size:2rem; box-shadow:0 0 20px rgba(61,232,164,0.35);">
            🛡️
        </div>
        <span style="display:inline-block; font-size:0.75rem; font-weight:900; letter-spacing:0.08em; color:#3de8a4; background:rgba(61,232,164,0.18); border:1px solid rgba(61,232,164,0.4); padding:4px 14px; border-radius:999px; margin-bottom:12px;">
            PROTECCIÓN PROFESIONAL RECOMENDADA
        </span>
        <h3 style="font-size:1.35rem; font-weight:800; color:#ffffff; margin:0 0 10px; text-transform:uppercase; letter-spacing:0.02em;">
            DESCUBRE NEXAGUARD SECURITY PRO
        </h3>
        <p style="color:#cad7f5; font-size:0.94rem; line-height:1.6; margin:0 0 20px; font-weight:500;">
            Mantén tu WordPress permanentemente blindado con la red de ciberinteligencia global en la nube y asistencia experta para incidentes graves.
        </p>
        
        <div style="background:rgba(255,255,255,0.03); border:1.5px solid rgba(255,207,51,0.35); border-radius:12px; padding:16px 18px; margin-bottom:20px; text-align:left;">
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">
                <span style="color:#ffcf33; font-weight:800; font-size:0.88rem;">⚡ PLAN NEXAGUARD SECURITY PRO</span>
                <span style="color:#3de8a4; font-weight:800; font-size:0.95rem;">$9.99 <span style="font-size:0.75rem; color:#a0acd2;">/ mes</span></span>
            </div>
            <ul style="margin:0; padding-left:18px; color:#dbe4ff; font-size:0.82rem; line-height:1.6;">
                <li>✓ Feeds de reglas Zero-Day en vivo desde la nube</li>
                <li>✓ Bloqueo colaborativo de botnets e IPs mundiales (Auto-Jail)</li>
                <li>✓ Alertas instantáneas por Webhooks (Discord y Telegram)</li>
            </ul>
        </div>

        <div style="display:flex; flex-direction:column; gap:10px;">
            <a href="https://www.nexaguards.com/#planes" target="_blank" class="btn-ng btn-ng-primary" style="justify-content:center; font-size:1rem; padding:12px 20px;">
                ⚡ Ver Planes NexaGuard PRO ($9.99/mes)
            </a>
            <div style="display:flex; gap:10px; justify-content:center; align-items:center; flex-wrap:wrap; margin-top:4px;">
                <a href="https://www.nexaguards.com/#contacto" target="_blank" style="color:#ffcf33; font-size:0.84rem; text-decoration:none; font-weight:700;">
                    👨‍💻 ¿Prefieres ayuda humana experta? Plan Rescate ($99)
                </a>
            </div>
            <div style="display:flex; gap:10px; justify-content:center; align-items:center; flex-wrap:wrap; margin-top:6px;">
                <button type="button" class="btn-ng btn-ng-link btn-switch-to-key" style="color:#8f9fc7; font-size:0.82rem; text-decoration:underline;">
                    🔑 Ya tengo mi clave de licencia
                </button>
                <span style="color:rgba(255,255,255,0.25);">·</span>
                <button type="button" id="btn-close-quota-modal" class="btn-ng btn-ng-outline" style="font-size:0.84rem; padding:5px 14px;">
                    Cerrar
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ======================================================================= -->
<!-- MODAL INTERACTIVO: RESUMEN FORENSE DE AMENAZAS EN EL RADAR             -->
<!-- ======================================================================= -->
<div id="threat-summary-modal" class="ng-modal" style="display:none; z-index:9999999 !important;">
    <div class="ng-modal-box threat-summary-box">
        <!-- Encabezado táctico de alto contraste -->
        <div class="tsm-header">
            <div class="tsm-title-area">
                <div class="tsm-icon-box">🛡️</div>
                <div>
                    <div class="tsm-badge">RADAR FORENSE ACTIVO // RESUMEN TÁCTICO</div>
                    <h3 class="tsm-heading">Amenazas e Intrusiones Interceptadas</h3>
                    <p class="tsm-subheading">Auditoría perimetral de vectores hostiles mitigados en tiempo real por NexaGuard WAF.</p>
                </div>
            </div>
            <button type="button" class="tsm-close" id="btn-close-threat-summary" title="Cerrar resumen">✕</button>
        </div>

        <!-- Tarjetas KPI de alto contraste -->
        <div class="tsm-stats-grid">
            <div class="tsm-stat-card tsm-stat-total">
                <div class="tsm-stat-icon">🚨</div>
                <div class="tsm-stat-content">
                    <span class="tsm-stat-num" id="tsm-stat-total">0</span>
                    <span class="tsm-stat-title">Ataques Bloqueados</span>
                </div>
            </div>
            <div class="tsm-stat-card tsm-stat-scanners">
                <div class="tsm-stat-icon">🐉</div>
                <div class="tsm-stat-content">
                    <span class="tsm-stat-num" id="tsm-stat-scanners">0</span>
                    <span class="tsm-stat-title">Kali Linux / Scanners</span>
                </div>
            </div>
            <div class="tsm-stat-card tsm-stat-waf">
                <div class="tsm-stat-icon">⚡</div>
                <div class="tsm-stat-content">
                    <span class="tsm-stat-num" id="tsm-stat-waf" style="color:#00ff88;">100%</span>
                    <span class="tsm-stat-title">Mitigación WAF (403)</span>
                </div>
            </div>
        </div>

        <!-- Barra de herramientas de la lista -->
        <div class="tsm-toolbar">
            <div class="tsm-toolbar-label">
                <span>📋 HISTORIAL CRONOLÓGICO DE INTRUSIONES</span>
                <span class="tsm-badge-count" id="tsm-badge-count">0 eventos</span>
            </div>
            <div class="tsm-toolbar-actions">
                <button type="button" class="btn-tsm-export" id="btn-tsm-export-csv" title="Descargar informe forense completo en formato CSV">
                    📥 Exportar CSV
                </button>
                <button type="button" class="btn-tsm-export" id="btn-tsm-export-json" title="Descargar registro forense en formato JSON">
                    📥 Exportar JSON
                </button>
                <button type="button" class="btn-ng btn-ng-outline btn-tsm-clear" id="btn-tsm-clear-logs" title="Vaciar registro del radar">
                    🗑️ Vaciar Historial
                </button>
            </div>
        </div>

        <!-- Feed scrollable con diseño hacker de alto contraste -->
        <div class="tsm-feed-scroll" id="tsm-feed-container">
            <!-- Inyectado dinámicamente vía JavaScript -->
        </div>

        <!-- Pie de modal -->
        <div class="tsm-footer">
            <div class="tsm-footer-meta">
                <span class="tsm-dot-live"></span>
                <span class="tsm-footer-text">Sensores perimetrales monitoreando puertos HTTP/HTTPS y REST API activamente.</span>
            </div>
            <button type="button" class="btn-ng btn-ng-primary" id="btn-close-threat-summary-foot">
                Entendido / Cerrar
            </button>
        </div>
    </div>
</div>

